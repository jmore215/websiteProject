<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 3
				This is the Contact_me.php page that 
				will be called by Controller3.php
				to be used by program3.php
	 Due Date : June 29, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<!DOCTYPE html>               <!-- this is a declaration used in HTML 5. It tells the browsers that this is HTML 5 -->

<html>

  <head>
  <title>MorenoJContact_me</title>
  </head>
       
  <body>
  
	<?php include('Moreno_header.html'); ?>
	
	<tr><td> &nbsp; </td></tr>
	
	<b><center><font face=Arial color=red>CONTACT ME</font></center></b>
	
	<tr><td> &nbsp; </td></tr>
	  
	<?php include('mainMenu.php'); ?>
	  
	<tr><td> &nbsp; </td></tr>
	
	<form method="post" action="Contact_me_Controller.php">
	  <table style="width: 50%; margin: 0px auto; padding-right: 10%;">
	        
			<!--Input Labels and Fields-->
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Your Email</td>
               <td style="width: 20%;">
                  <input type="text" name="Email" value="<?php echo $Email ?>" style="width: 100%;">
               </td>
            </tr>
            
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Last Name</td>
               <td style="width: 20%;">
                  <input id="birth" type="text" name="LastName" value="<?php echo $LastName ?>" style="width: 100%;">
               </td>
            </tr>
			
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; First Name</td>
               <td style="width: 20%;">
                  <input type="text" name="FirstName" value="<?php echo $FirstName ?>" style="width: 100%;">
               </td>
            </tr>
			
			<tr><td> &nbsp; </td></tr>
			
			<!--Radio Buttons-->
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Coffee</td>
			   <td style="width: 20%; text-align: left;">
                   <table>
			          <tr>
					     <td text-align: left> 
                           <input type="radio" <?php if ($Coffee == "Light")   echo "checked"; ?> name="Coffee" value="Light">Light
                           <input type="radio" <?php if ($Coffee == "Cuban")   echo "checked"; ?> name="Coffee" value="Cuban">Cuban
                           <input type="radio" <?php if ($Coffee == "Sweet")   echo "checked"; ?> name="Coffee" value="Sweet">Sweet 
					     </td>
	                  </tr>
			       </table>
			   </td>
	        </tr> 
			
			<!--Check Boxes-->
			<tr>
		       <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Major</td>
               <td style="width: 20%;">
                   <table>
                      <tr>
                         <td "text-align: left"> <input type="checkbox" name="IT" <?php if ($IT == "IT") echo checked;?> value="IT">IT &nbsp; &nbsp;&nbsp;</td>
                         <td> <input type="checkbox" name="CS" <?php if ($CS == "CS") echo checked;?> value="CS">CS&nbsp; &nbsp; &nbsp;&nbsp;</td>
                         <td> <input type="checkbox" name="Robotics" <?php if ($Robotics == "Robotics") echo checked;?> value="Robotics">Robotics &nbsp;</td>
                      </tr> 
                   </table>
               </td>
            </tr>
			
			<tr><td> &nbsp; </td></tr>
			
			<!--Dropdown-->
            <tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Dropdowns</td>
               <td style="width: 20%; text-align: left;">
                   <select name="Dropdowns" style="width: 100%;">
                     <option value="Option 1" <?php if ($Dropdowns == "Option 1") echo selected ?> > Option 1 </option>
                     <option value="Option 2" <?php if ($Dropdowns == "Option 2") echo selected ?> > Option 2 </option>
                     <option value="Option 3" <?php if ($Dropdowns == "Option 3") echo selected ?> > Option 3 </option>
                   </select>
               </td>
            </tr>
			
			<tr><td> &nbsp; </td></tr>
			
			<!--Text Area-->
			<tr>
			   <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Comments</td>
			   <td style="width: 20%;"> 
			      <textarea name="Comments" rows="5" cols="25">
				  <?php echo $Comments;?>
				  </textarea><br><br>
			   </td>
			</tr>
			
			<tr>
			   <td style="width: 5%;"></td>
			   <td style="width: 20%;" align=center>
				  <input type="submit" name="Submit" value="Submit">&nbsp; &nbsp;
				  <input type="reset" name="Clear" value="Clear">
				  <input type="hidden" name="found"  value="<?php echo $found ?>" >  <!--this line is a hidden debuging variable-->
			   </td>
			</tr>
			
			<tr><td> &nbsp; </td></tr>
	  </table>
    </form>
	
	<?php include('mainMenu.php'); ?>
	
	<tr><td> &nbsp; </td></tr>
	
  </body>       
</html>