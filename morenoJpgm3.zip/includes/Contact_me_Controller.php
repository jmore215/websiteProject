<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 3
				This is the Contact_me_Controller.php page that 
				will be called by Contact_me.php
				to be used for program3.php
	 Due Date : June 29, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<html>
  
  <body>
      
    <?php
	
	  if(isset($_POST['Submit']))
	  {
		
        $Email        = $_POST['Email'];
	    $LastName     = $_POST['LastName'];
	    $FirstName    = $_POST['FirstName'];
        $Coffee       = $_POST['Coffee'];
        $IT           = $_POST['IT'];
        $CS           = $_POST['CS'];
        $Robotics     = $_POST['Robotics'];
		$Dropdowns    = $_POST['Dropdowns'];
        $Comments     = $_POST['Comments'];
		
		$to           = "michael.robinson@cs.fiu.edu";
		$subject      = "From Teaching Website jmore215";
		
		$body = 
"Your Email     $Email
Last Name     $LastName
First Name     $FirstName\n
Coffee            $Coffee
Major              $IT $CS $Robotics\n
Dropdowns    $Dropdowns\n
Comments     $Comments";
				  
		mail($to, $subject, $body);
		
		include('Moreno_header.html');
		
		echo "<b><center><font face=Arial color=red>CONTACT ME</font></center></b>";
		echo "<br>";
		
		include('mainMenu.php');
		echo "<br>";
		
		echo "<center>Your message has been submitted to $to </center>";
		echo "<center>thank you</center>";

	  }
	
	?>
                 
  </body>

</html>