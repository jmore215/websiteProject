<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 3
				This is the Styles.php page that 
				will be used for program3.php
	 Due Date : June 29, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<!DOCTYPE html>  <!-- this is a declaration used in HTML 5. It tells the browsers to use HTML 5 -->

<html>                        <!-- start of html (Hyper Text Markup Language) --> 

   <head>                     <!-- start of the head section -->
      
      <title>MorenoJStyles.php</title>  

      <!-- this is how we call an external css file -->
	  <link rel="stylesheet" type="text/css" href="../css/style.css" />
	  
   </head>                    <!-- end of the head section -->
   
   <body>
   
     <!-- class is used multiple times, at any place in html -->
	 <div class="bodyClass-one">
		<h2>Jennifer Moreno</h2>
		<strong>CGS 4854-RVCC (53199) Websiteconmgmt</strong><br><br>
		<strong>Syllabus 2020 Summer for classes held Online</strong>         
	 </div>
   
   </body>  
  
</html>                       <!-- close of html (Hyper Text Markup Language) --> 
  