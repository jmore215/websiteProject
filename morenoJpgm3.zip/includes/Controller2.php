<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 2
				This is the Controller2.php page that 
				will be called by program2.php
	 Due Date : June 11, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->


<html>

  <head>
     <title>Controller2.php</title>
  </head>
          
  <body>
  
     <?php
        //extract the data inputed by the user creating global php fields
        //variables are declared beginning with $ symbol
        //['Telephone'] refers to the name='' locations in program2.php
        //   and stores that value into $Telephone
        //POST extracts data from form in program2.php
        //End each line with ;
        $Telephone    = $_POST['Telephone'];
        $Email        = $_POST['Email'];
	    $LastName     = $_POST['LastName'];
	    $FirstName    = $_POST['FirstName'];
        $Address      = $_POST['Address'];
	    $City         = $_POST['City'];
	    $State        = $_POST['State'];
	    $Country      = $_POST['Country'];
	    $Zip          = $_POST['Zip'];
	    $Dropdowns    = $_POST['dropdowns'];
        $Coffee       = $_POST['Coffee'];
        $IT           = $_POST['IT'];
        $CS           = $_POST['CS'];
        $Robotics     = $_POST['Robotics'];
        $Cyber        = $_POST['Cyber'];
        $Comments     = $_POST['Comments'];           
   
        //verify that the data entered by the user is being received
        //the . is used to concatenate variable and break
        echo "Telephone: ".$Telephone."<br>"; 
	    echo "Email: ".$Email."<br>";
        echo "Last Name: ".$LastName."<br>"; 
	    echo "First Name: ".$FirstName."<br>";  
        echo "Address: ".$Address."<br>"; 
        echo "City: ".$City."<br>";
	    echo "State: ".$State."<br>"; 
	    echo "Country: ".$Country."<br>"; 
	    echo "Zip: ".$Zip."<br>";
        echo "Dropdowns: ".$Dropdowns."<br>"; 	   
        echo "Coffee: ".$Coffee."<br>";  
        echo "IT: ".$IT."<br>";  
        echo "CS: ".$CS."<br>";  
        echo "Robotics: ".$Robotics."<br>";  
        echo "Cyber: ".$Cyber."<br>";  
        echo "Comments: ".$Comments."<br>";  
	   
	    if ( $_POST['Save'] )
        { 
           echo "You pressed the Save button.";
        }
		else if ( $_POST['Find'] )
        { 
           echo "You pressed the Find button.";
        }
        else if ( $_POST['Modify'] )
        {  
           echo "You pressed the Modify button.";
        }
        else if ( $_POST['Delete'] )
        { 
           echo "You pressed the Delete button.";
        }
        else
        { 
           echo "<br><h1> You pressed the UNKNOWN button.</h1>";   
        }

     ?> <!--end Controller2.php-->
                 
  </body>

</html>