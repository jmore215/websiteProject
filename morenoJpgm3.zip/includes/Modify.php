<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 3
				This is the Modify.php page that 
				will be called by Controller3.php
				to be used in program3.php
	 Due Date : June 29, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<html>

  <body>
        
    <?php
        
       $found = $_POST['found']; 
	   
	   if (  ( strlen(trim($found)) > 0 ) && ($found == $Telephone) )
       {               
                  
          $query = "UPDATE customers 
                    SET Email         =  '$Email',
						LastName      =  '$LastName',
						FirstName     =  '$FirstName',  
                        Address       =  '$Address',
						City          =  '$City',
						State         =  '$State',
						Country       =  '$Country',
						Zip           =  '$Zip',
                        Dropdowns     =  '$Dropdowns',
                        Coffee        =  '$Coffee',
                        IT            =  '$IT',
                        CS            =  '$CS',
                        Robotics      =  '$Robotics',
                        Cyber         =  '$Cyber',
                        Comments      =  '$Comments'  
                                 
                   WHERE Telephone = '$Telephone'";
                       
          $sql = mysqli_query( $connection,$query );
                                              
          if ($sql)
          {
             $message ="<span style=\"color: red;\">RECORD $found MODIFIED</span><br\>";
          }   
          else
          {
             //echo "Problem updating record. MySQL Error: " . mysqli_error($connection);
             $message ="<span style=\"color: red;\">PROBLEM UPDATING RECORD</span><br\>";
          }
             
       }   
       else
       {
          $message ="<span style=\"color: red;\">FIND THE RECORD BEFORE MODIFING IT</span><br\>";
       }
           
    ?>
            
  </body>
                
</html>
