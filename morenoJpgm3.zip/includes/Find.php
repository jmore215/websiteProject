<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 3
				This is the Find.php page that 
				will be called by Controller3.php
				to be used in program3.php
	 Due Date : June 29, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<html>
                     
  <body>
                        
    <?php
	
	   //$sql="SELECT * FROM customers ORDER BY Telephone";
           
       $sql="SELECT * FROM customers where Telephone = '$Telephone'";
             
       if ($result=mysqli_query($connection,$sql))
       {
          //printf("Result of mysqli_query(connection,sql) = %d<br>", $result);
          
          // Return the number of rows in result set
          $rowcount=mysqli_num_rows($result);
                   
          //printf("Result set has %d rows.\n",$rowcount);
             
                        
          while( $row = mysqli_fetch_array( $result ) )
          {
             $Telephone    = $row['Telephone'];     //primary key
			 $Email        = $row['Email'];         //type="text"
			 $LastName     = $row['LastName'];      //type="text"
             $FirstName    = $row['FirstName'];     //type="text"
             $Address      = $row['Address'];       //type="text"
             $City         = $row['City'];          //type="text"
			 $State        = $row['State'];         //type="text"
			 $Country      = $row['Country'];       //type="text"
			 $Zip          = $row['Zip'];           //type="text"
             $Dropdowns    = $row['Dropdowns'];     //type="dropdown" 
             $Coffee       = $row['Coffee'];        //type="radio"
             $IT           = $row['IT'];            //type="checkbox"
             $CS           = $row['CS'];            //type="checkbox" 
             $Robotics     = $row['Robotics'];      //type="checkbox"
             $Cyber        = $row['Cyber'];         //type="checkbox"
             $Comments     = $row['Comments'];      //type="textarea"          
          }
		  
          //printf("\ni am here in find.php\n [%s] [%s]", $Telephone, $FirstName );
          //echo "(".$Telephone." ".$FirstName.")";


          $Telephone=trim($Telephone); //take all front and back spaces out

                
          //if (mysqli_query($connection, $sql)) 
          if ( $rowcount )
          {
             $found = $Telephone;
             $message ="<span style=\"color: red;\">RECORD $found FOUND</span><br\>";
          } 
          else if( strlen($Telephone) ==0 )           
          {
             $message ="<span style=\"color: red;\">Telephone CAN NOT BE EMPTY</span><br>";
             //echo "<br>Error: " . $sql . " " . mysqli_error($connection);
                  
             //clear data in variables       
             //$Telephone    = "";
			 $Email        = "";
			 $LastName     = "";
             $FirstName    = "";
             $Address      = "";
			 $City         = "";
			 $State        = "";
			 $Country      = "";
			 $Zip          = "";
             $Dropdowns    = "";
             $Coffee       = "";
             $IT           = "";
             $CS           = "";
             $Robotics     = "";
             $Cyber        = "";
             $Comments     = "";            
                      
             $found        = "";  
          }
          else 
          {
             $message ="<span style=\"color: red;\">RECORD $Telephone NOT FOUND</span><br>";
             //echo "<br>Error: " . $sql . " " . mysqli_error($connection);
                  
             //clear data in variables       
             //$Telephone    = "";
             $Email        = "";
			 $LastName     = "";
             $FirstName    = "";
             $Address      = "";
			 $City         = "";
			 $State        = "";
			 $Country      = "";
			 $Zip          = "";
             $Dropdowns    = "";
             $Coffee       = "";
             $IT           = "";
             $CS           = "";
             $Robotics     = "";
             $Cyber        = "";
             $Comments     = "";            
                      
             $found        = "";  
          } 
       }        
    ?>

  </body>

</html>
