<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 3
				This is the Clear.php page that 
				will be called by Controller3.php
				to be used in program3.php
	 Due Date : June 29, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<html>
       
  <body>
                                     
    <?php
                  
       $Telephone    = "";
       $Email        = "";
	   $LastName     = "";
       $FirstName    = "";
       $Address      = "";
	   $City         = "";
	   $State        = "";
	   $Country      = "";
	   $Zip          = "";
       $Dropdowns    = "";
       $Coffee       = "";
       $IT           = "";
       $CS           = "";
       $Robotics     = "";
       $Cyber        = "";
       $Comments     = "";          
     
       $found        = "";  
                       
    ?>
                    
  </body>
            
</html>
