<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 2
				This is the mainMenu.php page that 
				will be called by program2.php
	 Due Date : June 11, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<!DOCTYPE html>               <!-- this is a declaration used in HTML 5. It tells the browsers that this is HTML 5 -->


<html>                        <!-- start of html (Hyper Text Markup Language) --> 

   <head>                     <!-- start of the head section -->
      
      <title>mainMenu.php</title>
	  
	  <style type="text/css">

        nav ul ul 
        {
            display: none;
        }      
        
        nav ul li:hover > ul 
        {
            display: block;
        }
         
        nav ul 
        {
            background: #efefef; 
            background: linear-gradient(top, #efefef 0%, #bbbbbb 100%);  
            background: -moz-linear-gradient(top, #efefef 0%, #bbbbbb 100%); 
            background: -webkit-linear-gradient(top, #efefef 0%,#bbbbbb 100%); 
            box-shadow: 0px 0px 9px rgba(0,0,0,0.15);
            padding: 0px 15px;
            border-radius: 10px;  
            list-style: none;
            position: relative;
            display: inline-table;
        }

        nav ul:after 
        {
                content: ""; clear: both; display: block;
	    }

        nav ul li 
        {
                float: left;
        }        

	    nav ul li:hover 
        {
                background: #4b545fi; 
                background: linear-gradient(top, #4f5964 0%, #5f6975 40%);
                background: -moz-linear-gradient(top, #4f5964 0%, #5f6975 40%);
                background: -webkit-linear-gradient(top, #4f5964 0%,#5f6975 40%);
        }                

        nav ul li:hover a 
        {
                color: thistle;
        }                

        nav ul li a 
        {
                display: block; padding: 20px 30px;
                color: purple; /* main menu name #757575;*/ text-decoration: none;
	    }
                
        nav ul ul 
        {
                background: lightslategrey; border-radius: 0px; padding: 0;
                position: absolute; top: 100%;
        }

        nav ul ul li 
        {
		        float: none; 
		        border-top: 1px solid white; /*#6b727c; */ /*border top */
		        border-bottom: 1px solid #575f6a; /*border down */
		        position: relative;
	    }
  
        nav ul ul li a:hover 
        {
                background: purple; /* #4b545f; */ /*submenu background color*/
        }
                
    </style>

   </head>                    <!-- end of the head section -->
   
   
   <body>                     <!-- start of the body section -->
    
      <nav align="center">
         <ul>
            <li><a href="../index.html">Home</a></li>
             
            <li><a href="#">Program 1</a>
               <ul>
                  <li><a href="pgm1.html">program 1</a></li>
                  <li><a href="Page1.html">page1</a></li>
                  <li><a href="Page2.html">page2</a></li>
                  <li><a href="Page3.html">page3</a></li>
                  <li><a href="Page4.html">page4</a></li>
                  <li><a href="../index.html">Home</a></li>
               </ul>
            </li>

            <li><a href="program2.php">Program 2</a></li>
			
			<li><a href="program3.php">Program 3</a></li>
         </ul>
      </nav>
	  
   </body>                    <!-- close of the body section -->
  
</html>                       <!-- close of html (Hyper Text Markup Language) --> 
  