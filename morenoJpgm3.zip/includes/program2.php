<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 2
				This is the program2.php page that 
				will call the Moreno_header.html and
				the mainMenu.php pages
	 Due Date : June 11, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<!DOCTYPE html>               <!-- this is a declaration used in HTML 5. It tells the browsers that this is HTML 5 -->


<html>                        <!-- start of html (Hyper Text Markup Language) --> 

   <head>                     <!-- start of the head section -->
      
      <title>MorenoJprogram2</title>  
	  

   </head>                    <!-- end of the head section -->
   
   
   <body>                     <!-- start of the body section -->
    
      <?php include('Moreno_header.html'); ?>
	  
	  <tr><td> &nbsp; </td></tr>
	  
	  <?php include('mainMenu.php'); ?>
	  
	  <tr><td> &nbsp; </td></tr>
	  
      <form method="post" action="Controller2.php">
	     <table style="width: 50%; margin: 0px auto; padding-right: 10%;">
	        <!--Input Labels and Fields-->
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Telephone</td>
               <td style="width: 20%;">
                  <input type="text" name="Telephone" value="" style="width: 100%;">
               </td>
            </tr>
            
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Email</td>
               <td style="width: 20%;">
                  <input id="birth" type="text" name="Email" value="" style="width: 100%;">
               </td>
            </tr>
			
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Last Name</td>
               <td style="width: 20%;">
                  <input type="text" name="LastName" value="" style="width: 100%;">
               </td>
            </tr>
			
            <tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; First Name</td>
               <td style="width: 20%;">
                  <input type="text" name="FirstName" value="" style="width: 100%;">
               </td>
            </tr>  
			
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Address</td>
               <td style="width: 20%;">
                  <input type="text" name="Address" value="" style="width: 100%;">
               </td>
            </tr>
			
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; City</td>
               <td style="width: 20%;">
                  <input type="text" name="City" value="" style="width: 100%;">
               </td>
            </tr>
			
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; State</td>
               <td style="width: 20%;">
                  <input type="text" name="State" value="" style="width: 100%;">
               </td>
            </tr>
			
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Country</td>
               <td style="width: 20%;">
                  <input type="text" name="Country" value="" style="width: 100%;">
               </td>
            </tr>
			
			<tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Zip</td>
               <td style="width: 20%;">
                  <input type="text" name="Zip" value="" style="width: 100%;">
               </td>
            </tr>
         
            <tr><td> &nbsp; </td> </tr>
           
		    <!--Dropdown-->
            <tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Dropdowns</td>
               <td style="width: 20%; text-align: left;">
                   <select name="dropdowns" style="width: 102.5%;">
                      <option value="option1"> Option 1 </option>
                      <option value="option2"> Option 2 </option>
                      <option value="option3"> Option 3 </option>
                   </select>
               </td>
            </tr>
            
            <tr><td> &nbsp; </td> </tr>            
            
			<!--Radio Buttons-->
            <tr>
               <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Coffee</td>
			   <td style="width: 20%; text-align: left;">
                   <table>
			          <tr>
					     <td text-align: left> 
                           <input type="radio" name="Coffee" value="Light">Light
                           <input type="radio" name="Coffee" value="Cuban">Cuban
                           <input type="radio" name="Coffee" value="Sweet">Sweet &nbsp; &nbsp;&nbsp;&nbsp;
		                   <input type="radio" name="Coffee" value="Decaf">Decaf
					     </td>
	                  </tr>
			       </table>
			   </td>
	        </tr>                                                   
            
			<!--Check Boxes-->
			<tr>
		       <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Major</td>
               <td style="width: 20%;">
                   <table>
                      <tr>
                         <td "text-align: left"> <input type="checkbox" name="IT" value="IT">IT &nbsp; &nbsp;&nbsp;</td>
                         <td> <input type="checkbox" name="CS"          value="CS">CS&nbsp; &nbsp; &nbsp;&nbsp;</td>
                         <td> <input type="checkbox" name="Robotics"    value="Robotics">Robotics &nbsp;</td>
                         <td> <input type="checkbox" name="Cyber" value="Cyber">Cyber</td>
                      </tr> 
                   </table>
               </td>
            </tr>
			
			<tr><td> &nbsp; </td> </tr>
			
			<!--Text Area-->
			<tr>
			   <td style="width: 5%; text-align: left;"> &nbsp; &nbsp; &nbsp; &nbsp; Comments</td>
			   <td style="width: 20%;"> 
			      <textarea name="Comments" rows="5" cols="25">
				  </textarea><br><br>
			   </td>
			</tr>
			
			<!--Display $message-->
			<tr>
			   <td style="width: 5%;"> </td>
			   <td style="width: 20%;" align=center>$message</td>
			</tr>
			
			<tr><td> &nbsp; </td> </tr>
			
			<tr>
			   <td style="width: 5%;"></td>
			   <td style="width: 20%;" align=center>
				  <input type="submit" name="Save" value="Save">&nbsp; &nbsp;
				  <input type="submit" name="Find" value="Find">&nbsp; &nbsp;
				  <input type="submit" name="Modify" value="Modify">&nbsp; &nbsp;
				  <input type="submit" name="Delete" value="Delete">&nbsp; &nbsp;
				  <input type="reset" name="ClearScreen" value="ClearScreen">
			   </td>
			</tr>
			
			<tr><td> &nbsp; </td> </tr>
			
	      </table>
       </form>
	   
	   <?php include('mainMenu.php'); ?>
   </body>                    <!-- close of the body section -->
  
</html>                       <!-- close of html (Hyper Text Markup Language) --> 
  