<!-- **************************************************
	 Author   : Jennifer Moreno
	 Course   : CGS 4854 Online Class
	 URL      : http://ocelot.aul.fiu.edu/~jmore215
	 Professor: Michael Robinson
	 Program  : Assignment 3
				This is the Controller3.php page that 
				will be called by program3.php
	 Due Date : June 29, 2020

	 I certify that this work is my own alone.


	 ..........{ Jennifer Moreno }..........
	 **************************************************
-->

<html>

  <head>
    <title>Controller3.php</title>
  </head>
  
  <body>
      
    <?php
	    
		//                                server               user       password      database     
       $connection = mysqli_connect("ocelot.aul.fiu.edu","sum20_jmore215","5775423","sum20_jmore215");
       if (mysqli_connect_errno())
       {
          echo "Failed to connect to MySQL: " . mysqli_connect_error();
       }
       else
       {  
          //echo "<br>I have connected to mySql<br>";            
             
          // Change database to another name if needed
             
          $dbName="sum20_jmore215"; 
          $db_selected = mysqli_select_db( $connection, $dbName );
                      
          if (!$db_selected)
          {
             die( $dbName . ' does not exist, can\'t use it ' . mysqli_error());
          }
          else
          {
             //echo "I selected database : " . $db_selected . " " . $dbName . "<br></h3>" ;
                   
             //access to a table                    
             $tableName = "customers";
                      
             $query = mysqli_query( $connection, "SELECT * FROM $tableName" );
                     
             //if table does not exist, create it 
             if(!$query)
             {
                echo "The ".$tableName." does not exists<br>";
                        
                echo "<br>Creating table : ".$tableName."<br>";
                       
                $sql = "CREATE TABLE ".$tableName."(
                        Telephone VARCHAR(20) NOT NULL,
                        PRIMARY KEY(Telephone),
                        Email VARCHAR(30),
						LastName VARCHAR(30),
						FirstName VARCHAR(30),
                        Address VARCHAR(30),
						City VARCHAR(30),
						State VARCHAR(30),
						Country VARCHAR(30),
						Zip VARCHAR(30),
						Dropdowns VARCHAR(8),
                        Coffee VARCHAR(30),
                        IT VARCHAR(2), 
                        CS VARCHAR(2),
                        Robotics VARCHAR(8),
                        Cyber VARCHAR(5),
                        Comments VARCHAR(200)
                        )";
                                
                $result = mysqli_query( $connection, $sql );
                         
                //confirm table creation
                if ($result)
                {
                   echo "table ". $tableName." created<br>";
                }
                else
                {
                   die ("Can\'t create ". $tableName." ". mysqli_error() );
                }
                     
             }//if(!$query) if table does not exist, create it 
                        
          }//end if (!$db_selected) connecting to db
                
       }//end if (mysqli_connect_errno()) connecting to mysql
		
	    //extract the data inputed by the user creating global php fields
        //variables are declared beginning with $ symbol
        //['Telephone'] refers to the name='' locations in program2.php
        //   and stores that value into $Telephone
        //POST extracts data from form in program2.php
        //End each line with ;
        $Telephone    = $_POST['Telephone'];
        $Email        = $_POST['Email'];
	    $LastName     = $_POST['LastName'];
	    $FirstName    = $_POST['FirstName'];
        $Address      = $_POST['Address'];
	    $City         = $_POST['City'];
	    $State        = $_POST['State'];
	    $Country      = $_POST['Country'];
	    $Zip          = $_POST['Zip'];
	    $Dropdowns    = $_POST['Dropdowns'];
        $Coffee       = $_POST['Coffee'];
        $IT           = $_POST['IT'];
        $CS           = $_POST['CS'];
        $Robotics     = $_POST['Robotics'];
        $Cyber        = $_POST['Cyber'];
        $Comments     = $_POST['Comments'];
		
		$found = $_POST['found'];
		
		
		if ( $_POST['Save'] )
        { 
           include('Save.php');
		   include( "program3.php" );
        }
		else if ( $_POST['Find'] )
        { 
           include('Find.php');
		   include( "program3.php" );
        }
        else if ( $_POST['Modify'] )
        {  
           include('Modify.php');
		   include( "program3.php" );
        }
        else if ( $_POST['Delete'] )
        { 
           include('Delete.php');
		   include( "program3.php" );
        }
        else if ( $_POST['Clear'] )
        { 
           include('Clear.php');
		   include( "program3.php" );
        }
		else if ( $_POST['Contact_Me'] )
        { 
           include('Contact_me.php');
        }
		else
        { 
           echo "<br><h1> You pressed the UNKNOWN button.</h1>";   
        }
		
		mysqli_close($connection); 
	
	
	?> <!--end controller3.php-->
                 
  </body>

</html>